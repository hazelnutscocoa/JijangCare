<div class="et-main-main clearfix  inner-content" id="wizard-content"  <?php if ($section != 'content') echo 'style="display:none"' ?>>
<?php 
	require_once 'content-jobs.php';
?>

	<?php et_wizard_nexstep_button (2); ?>
</div>


