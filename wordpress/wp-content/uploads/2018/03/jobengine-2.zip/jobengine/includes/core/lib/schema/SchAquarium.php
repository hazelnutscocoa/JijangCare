<?php
class SchAquarium extends SchCivicStructure{
	function __construct(){$this->namespace = "Aquarium";}
}