<?php
class SchEmploymentAgency extends SchLocalBusiness{
	function __construct(){$this->namespace = "EmploymentAgency";}
}