<?php
class SchEducationEvent extends SchEvent{
	function __construct(){$this->namespace = "EducationEvent";}
}