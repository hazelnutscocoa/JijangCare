<?php
class SchBone extends SchAnatomicalStructure{
	function __construct(){$this->namespace = "Bone";}
}