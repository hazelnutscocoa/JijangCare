<?php
class SchPawnShop extends SchStore{
	function __construct(){$this->namespace = "PawnShop";}
}