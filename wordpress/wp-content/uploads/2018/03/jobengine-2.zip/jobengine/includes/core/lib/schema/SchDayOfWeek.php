<?php
class SchDayOfWeek extends SchEnumeration{
	function __construct(){$this->namespace = "DayOfWeek";}
}