<?php
class SchHomeAndConstructionBusiness extends SchLocalBusiness{
	function __construct(){$this->namespace = "HomeAndConstructionBusiness";}
}