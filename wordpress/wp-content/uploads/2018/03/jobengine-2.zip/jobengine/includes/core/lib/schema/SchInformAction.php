<?php
class SchInformAction extends SchCommunicateAction{
	protected $event	=	'Event';
	function __construct(){$this->namespace = "InformAction";}
}