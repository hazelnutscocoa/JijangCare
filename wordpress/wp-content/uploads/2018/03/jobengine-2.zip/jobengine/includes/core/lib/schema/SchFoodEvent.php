<?php
class SchFoodEvent extends SchEvent{
	function __construct(){$this->namespace = "FoodEvent";}
}