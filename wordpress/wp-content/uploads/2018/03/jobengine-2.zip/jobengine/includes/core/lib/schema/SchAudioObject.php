<?php
class SchAudioObject extends SchMediaObject{
	protected $transcript	=	'Text';
	function __construct(){$this->namespace = "AudioObject";}
}