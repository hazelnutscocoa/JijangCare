<?php
class SchInteractAction extends SchAction{
	function __construct(){$this->namespace = "InteractAction";}
}