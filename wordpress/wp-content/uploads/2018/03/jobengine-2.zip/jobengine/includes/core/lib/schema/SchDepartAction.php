<?php
class SchDepartAction extends SchMoveAction{
	function __construct(){$this->namespace = "DepartAction";}
}