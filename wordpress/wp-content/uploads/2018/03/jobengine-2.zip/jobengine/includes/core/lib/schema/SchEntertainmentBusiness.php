<?php
class SchEntertainmentBusiness extends SchLocalBusiness{
	function __construct(){$this->namespace = "EntertainmentBusiness";}
}