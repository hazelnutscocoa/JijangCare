<?php
class SchBusReservation extends SchReservation{
	function __construct(){$this->namespace = "BusReservation";}
}