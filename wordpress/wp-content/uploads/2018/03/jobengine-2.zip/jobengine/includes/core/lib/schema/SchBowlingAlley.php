<?php
class SchBowlingAlley extends SchSportsActivityLocation{
	function __construct(){$this->namespace = "BowlingAlley";}
}