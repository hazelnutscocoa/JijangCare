<?php
class SchPhysicalExam extends SchEnumeration{
	function __construct(){$this->namespace = "PhysicalExam";}
}