<?php
class SchMedicalSymptom extends SchMedicalSignOrSymptom{
	function __construct(){$this->namespace = "MedicalSymptom";}
}