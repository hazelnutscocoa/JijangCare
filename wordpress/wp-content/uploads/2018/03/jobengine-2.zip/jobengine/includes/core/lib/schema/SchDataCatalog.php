<?php
class SchDataCatalog extends SchCreativeWork{
	protected $dataset	=	'Dataset';
	function __construct(){$this->namespace = "DataCatalog";}
}