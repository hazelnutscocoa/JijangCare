<?php
class SchMotorcycleDealer extends SchAutomotiveBusiness{
	function __construct(){$this->namespace = "MotorcycleDealer";}
}