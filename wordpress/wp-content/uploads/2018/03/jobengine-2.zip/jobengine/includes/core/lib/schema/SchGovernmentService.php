<?php
class SchGovernmentService extends SchService{
	protected $serviceOperator	=	'Organization';
	function __construct(){$this->namespace = "GovernmentService";}
}