<?php
class SchBlog extends SchCreativeWork{
	protected $blogPost	=	'BlogPosting';
	function __construct(){$this->namespace = "Blog";}
}