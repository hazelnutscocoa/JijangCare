<?php
class SchAutomotiveBusiness extends SchLocalBusiness{
	function __construct(){$this->namespace = "AutomotiveBusiness";}
}