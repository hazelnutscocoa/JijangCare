<?php
class SchArtGallery extends SchEntertainmentBusiness{
	function __construct(){$this->namespace = "ArtGallery";}
}