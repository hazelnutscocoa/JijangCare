<?php
class SchMedicalDevicePurpose extends SchEnumeration{
	function __construct(){$this->namespace = "MedicalDevicePurpose";}
}