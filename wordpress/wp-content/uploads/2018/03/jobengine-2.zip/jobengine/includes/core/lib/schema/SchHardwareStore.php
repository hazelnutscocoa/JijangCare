<?php
class SchHardwareStore extends SchStore{
	function __construct(){$this->namespace = "HardwareStore";}
}