<?php
class SchLiquorStore extends SchStore{
	function __construct(){$this->namespace = "LiquorStore";}
}