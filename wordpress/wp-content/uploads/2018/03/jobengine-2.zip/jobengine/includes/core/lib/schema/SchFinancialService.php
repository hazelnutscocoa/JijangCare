<?php
class SchFinancialService extends SchLocalBusiness{
	function __construct(){$this->namespace = "FinancialService";}
}