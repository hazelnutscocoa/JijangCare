<?php
class SchBodyOfWater extends SchLandform{
	function __construct(){$this->namespace = "BodyOfWater";}
}