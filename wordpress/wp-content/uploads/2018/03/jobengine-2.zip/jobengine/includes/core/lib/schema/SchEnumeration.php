<?php
class SchEnumeration extends SchIntangible{
	function __construct(){$this->namespace = "Enumeration";}
}