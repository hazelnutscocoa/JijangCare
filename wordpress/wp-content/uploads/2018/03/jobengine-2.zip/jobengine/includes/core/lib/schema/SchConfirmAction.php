<?php
class SchConfirmAction extends SchInformAction{
	function __construct(){$this->namespace = "ConfirmAction";}
}