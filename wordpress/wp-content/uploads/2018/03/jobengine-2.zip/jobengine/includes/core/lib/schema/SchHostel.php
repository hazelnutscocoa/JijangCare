<?php
class SchHostel extends SchLodgingBusiness{
	function __construct(){$this->namespace = "Hostel";}
}