<?php
class SchPhotograph extends SchCreativeWork{
	function __construct(){$this->namespace = "Photograph";}
}