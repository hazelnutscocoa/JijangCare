<?php
class SchEnergy extends SchQuantity{
	function __construct(){$this->namespace = "Energy";}
}