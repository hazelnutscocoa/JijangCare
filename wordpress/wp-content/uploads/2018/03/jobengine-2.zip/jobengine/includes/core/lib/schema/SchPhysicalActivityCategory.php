<?php
class SchPhysicalActivityCategory extends SchEnumeration{
	function __construct(){$this->namespace = "PhysicalActivityCategory";}
}