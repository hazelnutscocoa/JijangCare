<?php
class SchDryCleaningOrLaundry extends SchLocalBusiness{
	function __construct(){$this->namespace = "DryCleaningOrLaundry";}
}