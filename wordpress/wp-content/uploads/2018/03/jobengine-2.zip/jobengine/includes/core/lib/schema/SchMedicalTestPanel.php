<?php
class SchMedicalTestPanel extends SchMedicalTest{
	protected $subTest	=	'MedicalTest';
	function __construct(){$this->namespace = "MedicalTestPanel";}
}