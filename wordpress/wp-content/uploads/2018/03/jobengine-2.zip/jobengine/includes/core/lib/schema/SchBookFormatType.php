<?php
class SchBookFormatType extends SchEnumeration{
	function __construct(){$this->namespace = "BookFormatType";}
}