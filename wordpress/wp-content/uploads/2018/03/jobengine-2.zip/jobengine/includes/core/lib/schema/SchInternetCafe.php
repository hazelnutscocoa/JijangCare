<?php
class SchInternetCafe extends SchLocalBusiness{
	function __construct(){$this->namespace = "InternetCafe";}
}