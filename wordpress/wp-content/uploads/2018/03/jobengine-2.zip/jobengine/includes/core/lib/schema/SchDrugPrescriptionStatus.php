<?php
class SchDrugPrescriptionStatus extends SchMedicalEnumeration{
	function __construct(){$this->namespace = "DrugPrescriptionStatus";}
}