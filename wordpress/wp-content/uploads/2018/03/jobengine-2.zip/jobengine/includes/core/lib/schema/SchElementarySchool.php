<?php
class SchElementarySchool extends SchEducationalOrganization{
	function __construct(){$this->namespace = "ElementarySchool";}
}