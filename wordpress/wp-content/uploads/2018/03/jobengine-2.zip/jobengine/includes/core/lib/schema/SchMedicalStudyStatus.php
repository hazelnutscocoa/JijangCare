<?php
class SchMedicalStudyStatus extends SchMedicalEnumeration{
	function __construct(){$this->namespace = "MedicalStudyStatus";}
}