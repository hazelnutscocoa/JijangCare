<?php
class SchProfilePage extends SchWebPage{
	function __construct(){$this->namespace = "ProfilePage";}
}