<?php
class SchItemPage extends SchWebPage{
	function __construct(){$this->namespace = "ItemPage";}
}