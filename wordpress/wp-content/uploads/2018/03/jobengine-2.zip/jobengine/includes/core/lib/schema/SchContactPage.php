<?php
class SchContactPage extends SchWebPage{
	function __construct(){$this->namespace = "ContactPage";}
}