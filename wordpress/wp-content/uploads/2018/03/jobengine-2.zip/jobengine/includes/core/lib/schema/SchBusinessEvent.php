<?php
class SchBusinessEvent extends SchEvent{
	function __construct(){$this->namespace = "BusinessEvent";}
}