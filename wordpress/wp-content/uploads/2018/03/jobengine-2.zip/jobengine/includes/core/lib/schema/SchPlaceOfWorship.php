<?php
class SchPlaceOfWorship extends SchCivicStructure{
	function __construct(){$this->namespace = "PlaceOfWorship";}
}