<?php
class SchDiagnosticProcedure extends SchMedicalTest{
	function __construct(){$this->namespace = "DiagnosticProcedure";}
}