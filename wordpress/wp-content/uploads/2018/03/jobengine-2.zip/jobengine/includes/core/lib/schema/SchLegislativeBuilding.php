<?php
class SchLegislativeBuilding extends SchGovernmentBuilding{
	function __construct(){$this->namespace = "LegislativeBuilding";}
}