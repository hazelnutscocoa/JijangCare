<?php
class SchCheckAction extends SchFindAction{
	function __construct(){$this->namespace = "CheckAction";}
}