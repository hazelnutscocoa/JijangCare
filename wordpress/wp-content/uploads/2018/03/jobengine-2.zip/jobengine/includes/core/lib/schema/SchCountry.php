<?php
class SchCountry extends SchAdministrativeArea{
	function __construct(){$this->namespace = "Country";}
}