<?php
class SchBuddhistTemple extends SchPlaceOfWorship{
	function __construct(){$this->namespace = "BuddhistTemple";}
}