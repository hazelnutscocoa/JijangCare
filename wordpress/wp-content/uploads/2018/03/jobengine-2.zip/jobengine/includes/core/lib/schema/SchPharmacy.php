<?php
class SchPharmacy extends SchMedicalOrganization{
	function __construct(){$this->namespace = "Pharmacy";}
}