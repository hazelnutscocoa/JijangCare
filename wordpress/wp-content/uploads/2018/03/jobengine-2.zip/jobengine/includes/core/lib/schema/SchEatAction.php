<?php
class SchEatAction extends SchConsumeAction{
	function __construct(){$this->namespace = "EatAction";}
}