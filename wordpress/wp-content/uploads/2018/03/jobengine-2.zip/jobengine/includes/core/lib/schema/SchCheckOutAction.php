<?php
class SchCheckOutAction extends SchCommunicateAction{
	function __construct(){$this->namespace = "CheckOutAction";}
}