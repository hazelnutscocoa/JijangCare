<?php
class SchBakery extends SchFoodEstablishment{
	function __construct(){$this->namespace = "Bakery";}
}