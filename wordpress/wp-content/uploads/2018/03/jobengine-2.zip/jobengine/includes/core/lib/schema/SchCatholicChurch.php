<?php
class SchCatholicChurch extends SchPlaceOfWorship{
	function __construct(){$this->namespace = "CatholicChurch";}
}