<?php
class SchParkingFacility extends SchCivicStructure{
	function __construct(){$this->namespace = "ParkingFacility";}
}