<?php
class SchPoliceStation extends SchEmergencyService{
	function __construct(){$this->namespace = "PoliceStation";}
}