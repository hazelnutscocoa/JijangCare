<?php
class SchAchieveAction extends SchAction{
	function __construct(){$this->namespace = "AchieveAction";}
}