<?php
class SchLifestyleModification extends SchMedicalTherapy{
	function __construct(){$this->namespace = "LifestyleModification";}
}