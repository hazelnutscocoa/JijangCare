<?php
class SchDownloadAction extends SchTransferAction{
	function __construct(){$this->namespace = "DownloadAction";}
}