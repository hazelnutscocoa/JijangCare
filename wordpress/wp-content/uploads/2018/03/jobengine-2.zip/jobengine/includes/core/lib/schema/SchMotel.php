<?php
class SchMotel extends SchLodgingBusiness{
	function __construct(){$this->namespace = "Motel";}
}