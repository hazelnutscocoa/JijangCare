<?php
class SchDrawAction extends SchCreateAction{
	function __construct(){$this->namespace = "DrawAction";}
}