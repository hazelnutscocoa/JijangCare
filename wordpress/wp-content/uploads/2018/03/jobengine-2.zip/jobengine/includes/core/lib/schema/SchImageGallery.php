<?php
class SchImageGallery extends SchCollectionPage{
	function __construct(){$this->namespace = "ImageGallery";}
}