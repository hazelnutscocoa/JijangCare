<?php
class SchMosque extends SchPlaceOfWorship{
	function __construct(){$this->namespace = "Mosque";}
}