<?php
class SchCity extends SchAdministrativeArea{
	function __construct(){$this->namespace = "City";}
}