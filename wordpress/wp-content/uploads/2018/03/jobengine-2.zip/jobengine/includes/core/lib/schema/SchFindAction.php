<?php
class SchFindAction extends SchAction{
	function __construct(){$this->namespace = "FindAction";}
}