<?php
class SchApplyAction extends SchOrganizeAction{
	function __construct(){$this->namespace = "ApplyAction";}
}