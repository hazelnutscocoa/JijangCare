<?php
class SchMedicalOrganization extends SchLocalBusiness{
	function __construct(){$this->namespace = "MedicalOrganization";}
}