<?php
class SchFastFoodRestaurant extends SchFoodEstablishment{
	function __construct(){$this->namespace = "FastFoodRestaurant";}
}