<?php
class SchInsuranceAgency extends SchFinancialService{
	function __construct(){$this->namespace = "InsuranceAgency";}
}