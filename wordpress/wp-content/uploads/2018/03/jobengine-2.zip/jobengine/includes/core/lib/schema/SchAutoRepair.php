<?php
class SchAutoRepair extends SchAutomotiveBusiness{
	function __construct(){$this->namespace = "AutoRepair";}
}