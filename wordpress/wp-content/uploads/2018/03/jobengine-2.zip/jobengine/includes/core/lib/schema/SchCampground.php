<?php
class SchCampground extends SchCivicStructure{
	function __construct(){$this->namespace = "Campground";}
}