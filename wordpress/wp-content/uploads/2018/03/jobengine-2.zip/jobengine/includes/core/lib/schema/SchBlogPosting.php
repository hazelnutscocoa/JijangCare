<?php
/**
 * Project : classifiedengine
 * User: thuytien
 * Date: 10/29/2014
 * Time: 9:10 AM
 */

class SchBlogPosting extends SchArticle{
    function __construct(){$this->namespace = "BlogPosting";}

}