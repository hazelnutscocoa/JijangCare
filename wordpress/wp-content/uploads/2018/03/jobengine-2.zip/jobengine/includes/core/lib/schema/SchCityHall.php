<?php
class SchCityHall extends SchGovernmentBuilding{
	function __construct(){$this->namespace = "CityHall";}
}