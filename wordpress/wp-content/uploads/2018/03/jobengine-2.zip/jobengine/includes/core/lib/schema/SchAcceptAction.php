<?php
class SchAcceptAction extends SchAllocateAction{
	function __construct(){$this->namespace = "AcceptAction";}
}